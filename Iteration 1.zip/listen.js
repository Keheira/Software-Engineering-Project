//when tab opens get tab
var stime = ;
//Firebase Reference
var db = new Firebase

//listen for tab close
if(){
	var url = ;
	var ftime = ;

	//save data to firebase
	db.push({url:url, time:time});
}